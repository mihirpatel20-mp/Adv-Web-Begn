<html>
<head>
    <style>
        label{
            min-width: 120px;
            display: inline-block;
            text-align: right;
            padding-right: 5px;
        }
        .success{
            color: green;
        }
        .failure{
            color: red;
        }
    </style>
</head>
<body>
<div><p><b>Please complete form to register</b></p></div>

<form action="registration.php" method="POST">
    <p>
        <label>Name:</label>
        <input type="text" name="name" size="30">
    </p>
    <p>
        <label>Contact Number:</label>
        <input type="phone" name="contact" size="30">
    </p>
    <p>
        <label>Email:</label>
        <input type="email" name="email" size="30">
    </p>
    <p>
        <label>Password:</label>
        <input type="password" name="password" size="30">
    </p>
    <input type="submit" name="insert" value="Insert">
</form>
</div>
