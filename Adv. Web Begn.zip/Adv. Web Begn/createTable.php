 <?php
/*

//$mysqli = new mysqli("localhost","f31mpatel","f31mpatel136","registration_db")
$mydb = new mysqli("localhost","f31mpatel","f31mpatel136","C354_f31mpatel");

// Check connection 
if ($mydb -> connect_errno) 
{
  echo "Failed to connect to MySQL: " . $mydb -> connect_error;
  exit();
} 
*/


//creating tables using MySQL CREATE TABLE query

$create_query= "CREATE TABLE info (
    ID int NOT NULL PRIMARY KEY AUTO_INCREMENT,
    Name varchar(255),
    Contact varchar(255),
    Email varchar(255) NOT NULL,
    Password varchar(255),
    )";

//passing the values of query into result

$result = mysqli_query($mydb,$create_query);

if($result){
    echo "table created successfully";
}else{
    echo "Something went wrong";
}

?>
