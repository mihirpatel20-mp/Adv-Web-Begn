<?php
//$mysqli = new mysqli("localhost","f31mpatel","f31mpatel136","registration_db")
$mydb = new mysqli("localhost","f31mpatel","f31mpatel136","C354_f31mpatel");

// Check connection 
if ($mydb -> connect_errno) 
{
  echo "Failed to connect to MySQL: " . $mydb -> connect_error;
  exit();
}
