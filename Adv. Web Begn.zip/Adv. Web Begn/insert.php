<?php
/*

//$mysqli = new mysqli("localhost","f31mpatel","f31mpatel136","registration_db")
$mydb = new mysqli("localhost","f31mpatel","f31mpatel136","C354_f31mpatel");

// Check connection 
if ($mydb -> connect_errno) 
{
  echo "Failed to connect to MySQL: " . $mydb -> connect_error;
  exit();
} 
*/


//creating tables using MySQL CREATE TABLE query

$create_query= "CREATE TABLE information (
    ID int NOT NULL PRIMARY KEY AUTO_INCREMENT,
    Name varchar(255),
    Contact varchar(255),
    Email varchar(255) NOT NULL,
    Password varchar(255),
    )";

//passing the values of query into result

$result = mysqli_query($mydb,$create_query);

if($result){
    echo "table created successfully";
}else{
    echo "Something went wrong";
}




if(isset($_POST['insert'])) //value coming from form on the click of Insert button
{
    //insert data using MySQL query: 
    //INSERT INTO TABLE_NAME(COLUMN_NAME 1, COLUMN_NAME 2...COLUMN_NAME N) VALUES (VALUE 1, VALUE 2 .... VALUE N)
    
    $insert_query = "INSERT INTO information (`Name`, `Contact`, `Email`, `Password`, `Confirm_Password`) VALUES ('".$_POST['name']."','".$_POST['contact']."','".$_POST['email']."', '".$_POST['password']."', '".$_POST['confirm']."')";

    $insert_result = mysqli_query($mydb,$insert_query);
    if($insert_result){
    print "<p class='success'>Insert successfully!</p>";
    }else{
    print "<p class='failure'>Something went wrong</p>";
    }
}



?>