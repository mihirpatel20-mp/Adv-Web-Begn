<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title> Contact Us </title>

   <!-- swiper css link  -->
   <link href="https://unpkg.com/swiper@7/swiper-bundle.min.css" rel="stylesheet" />

   <!-- font awesome cdn link  -->
   <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" >

   <!-- custom css file link  -->
   <link href="css/style.css" rel="stylesheet" >

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="index.php" class="logo"><i class = "fas fa-plane-departure"></i> Happy Tours & Travel </a>

   <nav class="navbar">
      <a href="index.php"> Home </a>
      <a href="about.php"> About </a>
      <a href="deals.php"> Special Offers</a>
      <a href="privacy.php"> Privacy Policies </a>
      <a href="book.php"> Book </a>
      <a href="contact.php"> Contact Us </a>
      

   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>


<!-- header section ends -->

<div class="heading" style="background:url(images/privacyheader1.jpeg) no-repeat">
   <h1>Contact Us</h1>
</div>

<!-- about section starts  -->

<section class="about">

  
<div class="content">
      <h3>Do Not Hesitate! We'll Be Happy To Support You :) </h3>
      <p>We have always created our tours by building meaningful relationships with local communities, directly benefiting the people and places we visit.</p>
      <p>No matter the Travel Style, our tours balance well-planned itineraries with the flexibility to do your own thing and make the experience your own.</p>
      <p>When you travel with us, you experience first-hand our commitment to making travel a force for good is in everything we do.</p>
      <div class="icons-container">
         <div class="icons">
         <i class="fas fa-envelope"></i>
            <h3>Our Email Address</h3>
            <p>Mihirpatel123@outlook.com</p>
         </div>
         <div class="icons">
         <i class="fas fa-phone"></i>
            <h3>Our Contact Number:</h3>
            <p>+1 (250) 299-9898</p>

         </div>
         <div class="icons">
         <i class="fas fa-map-marker-alt"></i>
            <h3>Our Address</h3>
            <p>Kamloops, British Columbia - V2C 1N6</p>
         </div>
      </div>
   </div>

</section>



<!-- about section ends -->

<section class="booking">

   <h1 class="">For Inquiries, Provide Your Details and Your Concern </h1>
   <form action="" method="post" class="book-form">

   <div class="inputBox">
            <textarea placeholder="enter your message" cols="165" rows="10"></textarea>
            <br>
            <input type="submit" value="send message" class="btn">
            </div>
            
        </form>

        </section>   
            <section class="about">
            <div class="content">
            <h3>Our Location </h3>
            <br>

    <div class="mapouter"><div class="gmap_canvas"><iframe width="1300" height="500" id="gmap_canvas" 
    src="https://maps.google.com/maps?q=tru&t=&z=13&ie=UTF8&iwloc=&output=embed" frameborder="0" 
    scrolling="no" marginheight="0" marginwidth="0"></iframe><a href="https://123movies-to.org"></a><br>
    <style>.mapouter{position:relative;text-align:right;height:500px;width:1145px;}</style>
    <a href="https://www.embedgooglemap.net">embedgooglemap.net</a><style>.gmap_canvas {overflow:hidden;background:none!important;height:500px;width:1145px;}
    </style></div></div>

            </section>
      <h3>Our Location </h3>

    


















<!-- footer section starts  -->

<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="index.php"> <i class="fas fa-angle-right"></i> Home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> About</a>
         <a href="deals.php"> <i class="fas fa-angle-right"></i> Special Offers </a>
         <a href="privacy.php"> <i class="fas fa-angle-right"></i> Privacy Policies </a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> Book</a>
         <a href="contact.php"> <i class="fas fa-angle-right"></i> Contact Us</a>
      </div>

   

      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +1 (250) 299-9898 </a>
         <a href="#"> <i class="fas fa-envelope"></i> mihirpatel123@gmail.com </a>
         <a href="#"> <i class="fas fa-map"></i> Kamloops, BC - V2C 1N6 </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
         <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
      </div>

   </div>

   <div class="credit">Created by: <span>Mihirkumar Patel</span></div>

</section>

<!-- footer section ends -->











<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>