<!--
   Name: Mihirkumar Dilipbhai Patel
   Project Name: Happy Tours & Travel
-->





<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title> Home </title>

   <!-- swiper css link  -->
   <link href="https://unpkg.com/swiper@7/swiper-bundle.min.css" rel="stylesheet" />

   <!-- font awesome cdn link  -->
   <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" >

   <!-- custom css file link  -->
   <link href="css/style.css" rel="stylesheet" >

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="index.php" class="logo"><i class = "fas fa-plane-departure"></i> Happy Tours & Travel </a>

   <nav class="navbar">
   <a href="index.php"> Home </a>
      <a href="about.php"> About </a>
      <a href="deals.php"> Special Offers</a>
      <a href="privacy.php"> Privacy Policies </a>
      <a href="book.php"> Book </a>
      <a href="contact.php"> Contact Us </a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>

<!-- header section ends -->

<!-- home section starts  -->

<section class="home">

   <div class="swiper home-slider">

      <div class="swiper-wrapper">

         <div class="swiper-slide slide" style="background:url(images/homepage1.jpeg) no-repeat">
            <div class="content">
               <span>Adventure, Your Way</span>
               <h3> Adventure Begins Here </h3>
               <a href="deals.php" class="btn">Find Out More</a>
            </div>
         </div>

         <div class="swiper-slide slide" style="background:url(images/homepage2.jpeg) no-repeat">
            <div class="content">
               <span>explore, discover, travel</span>
               <h3>Make It Worth It</h3>
               <a href="deals.php" class="btn"> Find Out More</a>
            </div>
         </div>

         <div class="swiper-slide slide" style="background:url(images/homepage3.jpeg) no-repeat">
            <div class="content">
               <span>explore, discover, travel</span>
               <h3>Explore Something New</h3>
               <a href="deals.php" class="btn"> Find Out More</a>
            </div>
         </div>
         
      </div>

      <div class="swiper-button-next"></div>
      <div class="swiper-button-prev"></div>

   </div>

</section>

<!-- home section ends -->

<!-- services section starts  -->

<section class="services">

   <h1 class="heading-title"> What We Offer </h1>

   <div class="box-container">

      <div class="box">
         <img src="images/service1.png" alt="">
         <h3>CAMPING</h3>
      </div>

      <div class="box">
         <img src="images/service2.jpeg" alt="">
         <h3>INTERNATIONAL TRAVEL</h3>
      </div>

      <div class="box">
         <img src="images/service3.jpeg" alt="">
         <h3>TOUR GUIDE </h3>
      </div>

      <div class="box">
         <img src="images/service4.jpeg" alt="">
         <h3>JUNGLE SAFARI</h3>
      </div>

      <div class="box">
         <img src="images/service5.png" alt="">
         <h3>FAMILY TRAVEL</h3>
      </div>

      <div class="box">
         <img src="images/service6.jpeg" alt="">
         <h3>ADVENTURE</h3>
      </div>

   </div>

</section>

<!-- services section ends -->

<!-- home about section starts  -->

<section class="home-about">

   <div class="image">
      <img src="images/about1.gif" alt="">
   </div>

   <div class="content">
      <h3>Why travel with Happy Tours & Travel?</h3>
      <p>We've been in the buisness of small group adventure travel for more than 50 years. How’d we get here? By redefining the way travellers see the world. Check out how we’re creating the future of travel.</p>
      <a href="about.php" class="btn">read more</a>
   </div>

</section>

<!-- home about section ends -->

<!-- home packages section starts  -->

<section class="home-packages">

   <h1 class="heading-title"> Our Special Packages </h1>

   <div class="box-container">

      <div class="box">
         <div class="image">
            <img src="images/deal1.jpeg" alt="">
         </div>
         <div class="content">
            <h3>Ireland Tour</h3>
            <p>
The Cliffs of Moher are Ireland's most popular tourist attraction, welcoming more than 1 million visitors each year.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

      <div class="box">
         <div class="image">
            <img src="images/deal2.jpeg" alt="">
         </div>
         <div class="content">
            <h3>Germany Tour</h3>
            <p>Germany is home to many captivating travel destinations. Whether you're looking to soak up art, architecture and history or imbibe at Oktoberfest, this country appeals to a variety of tourists.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>
      
      <div class="box">
         <div class="image">
            <img src="images/deal3.jpeg" alt="">
         </div>
         <div class="content">
            <h3>Italy Tour</h3>
            <p>Italy is a country famous not only for its glorious landscapes, rich history and vibrant culture, but also for the Italian divine food that is a perfect fit for everyone.</p>
            <a href="book.php" class="btn">book now</a>
         </div>
      </div>

   </div>

   <div class="load-more"> <a href="deals.php" class="btn"> More Offers</a> </div>

</section>

<!-- home packages section ends -->

<!-- home offer section starts  -->

<section class="home-offer">
   <div class="content">
      <h3>Christmas Offer - Upto 40% Discount</h3>
      
      <p>Flying during the peak travel periods is never cheap if one doesn't book flights in advance. Generally, Christmas is the time when the demand for flight tickets and thus the airfare is high. Therefore, it is recommended to book flights in October or early November to get Christmas travel deals and also to score cheap flights in December.</p>
      <a href="book.php" class="btn">book now</a>
   </div>
</section>

<!-- home offer section ends -->
















<!-- footer section starts  -->

<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="index.php"> <i class="fas fa-angle-right"></i> Home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> About</a>
         <a href="deals.php"> <i class="fas fa-angle-right"></i> Special Offers </a>
         <a href="privacy.php"> <i class="fas fa-angle-right"></i> Privacy Policies </a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> Book</a>
         <a href="contact.php"> <i class="fas fa-angle-right"></i> Contact Us</a>
      </div>

   

      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +1 (250) 299-9898 </a>
         <a href="#"> <i class="fas fa-envelope"></i> mihirpatel123@gmail.com </a>
         <a href="#"> <i class="fas fa-map"></i> Kamloops, BC - V2C 1N6 </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
         <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
      </div>

   </div>

   <div class="credit">Created by: <span>Mihirkumar Patel</span></div>

</section>

<!-- footer section ends -->










<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>


<!--
   -----------------------------References-------------
   https://www.google.com/
   https://www.youtube.com/watch?v=rGtNYW_DK44
   https://www.youtube.com/watch?v=YzRDHxbw1RU
   https://www.youtube.com/watch?v=1GukDOICJg4
   https://www.youtube.com/user/youtube/videos
-->
