<!DOCTYPE html>
<html lang="en">
<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">
   <title> About </title>

   <!-- swiper css link  -->
   <link href="https://unpkg.com/swiper@7/swiper-bundle.min.css" rel="stylesheet" />

   <!-- font awesome cdn link  -->
   <link href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/5.15.4/css/all.min.css" rel="stylesheet" >

   <!-- custom css file link  -->
   <link href="css/style.css" rel="stylesheet" >

</head>
<body>
   
<!-- header section starts  -->

<section class="header">

   <a href="index.php" class="logo"><i class = "fas fa-plane-departure"></i> Happy Tours & Travel </a>

   <nav class="navbar">
   <a href="index.php"> Home </a>
      <a href="about.php"> About </a>
      <a href="deals.php"> Special Offers</a>
      <a href="privacy.php"> Privacy Policies </a>
      <a href="book.php"> Book </a>
      <a href="contact.php"> Contact Us </a>
   </nav>

   <div id="menu-btn" class="fas fa-bars"></div>

</section>


<!-- header section ends -->

<div class="heading" style="background:url(images/aboutheader1.jpeg) no-repeat">
   <h1>about us</h1>
</div>

<!-- about section starts  -->

<section class="about">

   <div class="image">
      <img src="images/about2.jpeg" alt="">
   </div>

   <div class="content">
      <h3>why choose us?</h3>
      <p>We have always created our tours by building meaningful relationships with local communities, directly benefiting the people and places we visit.</p>
      <p>No matter the Travel Style, our tours balance well-planned itineraries with the flexibility to do your own thing and make the experience your own.</p>
      <p>When you travel with us, you experience first-hand our commitment to making travel a force for good is in everything we do.</p>
      <div class="icons-container">
         <div class="icons">
            <i class="fas fa-smile"></i>
            <span> No Regrets </span>
         </div>
         <div class="icons">
            <i class="fas fa-thumbs-up"></i>
            <span>Excellent Service </span>
         </div>
         <div class="icons">
            <i class="fas fa-clock"></i>
            <span>24/7 Available</span>
         </div>
      </div>
   </div>

</section>

<!-- about section ends -->

<!-- reviews section starts  -->

<section class="reviews">

   <h1 class="heading-title"> Amazing Client Reviews </h1>

   <div class="swiper reviews-slider">

      <div class="swiper-wrapper">

         <div class="swiper-slide slide">
         <h3>Jacob Anderson</h3>
            <span>Explorer</span>
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>I had the most amazing holiday. This was my first time to Fiji and the InterContinental. I loved every moment & cannot wait to go back again. Booking with Travel Online was professional, easy & went without a hitch.</p>
            
            <img src="images/picture1.jpeg" alt="">
         </div>

         <div class="swiper-slide slide">
         <h3>Kevin Peterson</h3>
            <span>Traveler</span>
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>Thanks for such a great deal . We will be booking through you guys again ! quick responses to questions too :)</p>
            
            <img src="images/picture2.jpeg" alt="">
         </div>

         <div class="swiper-slide slide">
         <h3>David D'Souza</h3>
            <span>Explorer</span>
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>Really happy with the response to enquiries, and the helpfulness of staff when we needed to adjust a couple of little things.</p>
            
            <img src="images/picture3.jpeg" alt="">
         </div>

         <div class="swiper-slide slide">
         <h3>Luke Spahmann</h3>
            <span>Traveler</span>
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>Great service. I changed my booking a couple of times due to shows being postponed at the Crown. Very accomodating, quick replies and friendly staff.</p>
            
            <img src="images/picture4.jpeg" alt="">
         </div>

         <div class="swiper-slide slide">
         <h3>Kevin Murray</h3>
            <span>Explorer</span>
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>Happy to recommend travel online. Very helpful with everything.All went smoothly, I would book again.</p>
            
            <img src="images/picture5.jpeg" alt="">
         </div>

         <div class="swiper-slide slide">
         <h3>Murray Martin</h3>
            <span>Traveler</span>
            <div class="stars">
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
               <i class="fas fa-star"></i>
            </div>
            <p>Great service. Would absolutely book through this agent again.</p>
            
            <img src="images/picture6.jpeg" alt="">
         </div>

      </div>

   </div>

</section>

<!-- reviews section ends -->















<!-- footer section starts  -->

<section class="footer">

   <div class="box-container">

      <div class="box">
         <h3>quick links</h3>
         <a href="index.php"> <i class="fas fa-angle-right"></i> Home</a>
         <a href="about.php"> <i class="fas fa-angle-right"></i> About</a>
         <a href="deals.php"> <i class="fas fa-angle-right"></i> Special Offers </a>
         <a href="privacy.php"> <i class="fas fa-angle-right"></i> Privacy Policies </a>
         <a href="book.php"> <i class="fas fa-angle-right"></i> Book</a>
         <a href="contact.php"> <i class="fas fa-angle-right"></i> Contact Us</a>
      </div>

   

      <div class="box">
         <h3>contact info</h3>
         <a href="#"> <i class="fas fa-phone"></i> +1 (250) 299-9898 </a>
         <a href="#"> <i class="fas fa-envelope"></i> mihirpatel123@gmail.com </a>
         <a href="#"> <i class="fas fa-map"></i> Kamloops, BC - V2C 1N6 </a>
      </div>

      <div class="box">
         <h3>follow us</h3>
         <a href="#"> <i class="fab fa-instagram"></i> instagram </a>
         <a href="#"> <i class="fab fa-facebook-f"></i> facebook </a>
         <a href="#"> <i class="fab fa-linkedin"></i> linkedin </a>
         <a href="#"> <i class="fab fa-twitter"></i> twitter </a>
      </div>

   </div>

   <div class="credit">Created by: <span>Mihirkumar Patel</span></div>

</section>

<!-- footer section ends -->











<!-- swiper js link  -->
<script src="https://unpkg.com/swiper@7/swiper-bundle.min.js"></script>

<!-- custom js file link  -->
<script src="js/script.js"></script>

</body>
</html>